from django.apps import AppConfig


class TemplateappConfig(AppConfig):
    name = 'templateApp'