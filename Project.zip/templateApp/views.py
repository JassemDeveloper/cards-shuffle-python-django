from django.http import HttpResponse
from django.shortcuts import  render
from .models import Card
from random import randint
from .forms import ExcelForm
from openpyxl import Workbook,load_workbook

def handle_uploaded_file(f):
    with open('templateApp/upload/'+f.name, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)

def shuffuleResult():
    count=Card.objects.count()
    numbers=[]
    cards_data = []
    card_data = Card.objects.all()
    for card in card_data:
        cards_data.append({
            'card_details': card.card_details,
            'card_image': card.card_image
        })
    for i in range(count - 1):
        rand = randint(0, count-1)
        if rand not in numbers:
            numbers.append(rand)
    check_len = len(numbers)
    if check_len >0 and check_len < count:
        for j in range(count):
            if j not in numbers:
                numbers.append(j);

    finalAarr=[]
    for num in numbers:
        finalAarr.append(cards_data[num])

    return finalAarr

def index(request):
    form = ExcelForm()
    wbData=''
    html=''
    if request.method == 'POST':
        form = ExcelForm(request.POST, request.FILES)
        if form.is_valid():
            file = request.FILES['your_file']
            wbData = ProcessExcelFile(file)
	    #create card html markup
            html = html_markup(wbData)
            #ProcessExcelFileToCreateDummyData(file)
	    #upload file to /upload folder
            #handle_uploaded_file(file)
        else:
            form = ExcelForm()
    finalArr = shuffuleResult()
    data = {'data': finalArr, 'form': form, 'wbData': wbData, 'html': html}

    return render(request, 'templateApp/index.html', data)

def ProcessExcelFile(filename):
    wb = load_workbook(filename)
    dataByWorkbook = []
    dataBySheet = []
    for sheet in wb:
        sheet_name=sheet.title
        ws = wb[sheet_name]
        row_total = ws.max_row
        cols_total=ws.max_column
        collect_date = []
        for row_num in range(1,row_total+1):
            data = ""
            for col_num in range(1,cols_total+1):
                val = ws.cell(row_num,col_num)
                if col_num == cols_total:
                    if val.value == None:
                        data += str(val.value)
                    else:
                        data += str(val.value)
                else:
                    if val.value == None:
                        data +=' ;'
                    else:
                        data += str(val.value + ';')

            collect_date.append(data)
        dataBySheet.append({
            'SheetName': sheet_name,
            'SheetData': collect_date
        })
    dataByWorkbook.append({
        "Workbook": filename.name,
        "Sheets": dataBySheet
    })
    html_markup(dataByWorkbook)

    return dataByWorkbook
   # print(dataByWorkbook)


def html_markup(data):
    html = ''
    for d in data:
        for dd in d['Sheets']:
            count = 0
            html += '<table>'
            for ddd in dd['SheetData']:
                html += f'<tr>'
                for dddd in ddd.split(';'):
                    if count == 0:
                        html +=f'<th>{dddd}</th>'
                    else:
                        html +=f'<td>{dddd}</td>'
                count += 1
                html += '</tr>'
            html += '</table>'
    return html

'''
    collect_date1 = []
    for newData in d:
        element = []
        for newData1 in newData.split(';'):
            element.append(newData1)
    collect_date1.append(element)
    print(collect_date1)
'''

def ProcessExcelFileToCreateDummyData(filename):
    wb = load_workbook(filename)
    for sheet in wb:
        sheet_name=sheet.title
        ws = wb[sheet_name]
        row_total = ws.max_row
        for row_num in range(2,row_total+1):
            card_details = ws.cell(row_num, 1).value
            card_image = ws.cell(row_num, 2).value
            c = Card(card_details=card_details, card_image=card_image)
            c.save()
