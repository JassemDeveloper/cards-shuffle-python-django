from django.db import models


class Card(models.Model):
    card_details=models.CharField(max_length=200)
    card_image=models.CharField(max_length=2000)