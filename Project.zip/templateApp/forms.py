from django import forms


class ExcelForm(forms.Form):
    your_file = forms.FileField()