from django.contrib import admin
from .models import Card


class CardAdmin(admin.ModelAdmin):
    list_display = ('card_details', 'card_image')


admin.site.register(Card, CardAdmin)
